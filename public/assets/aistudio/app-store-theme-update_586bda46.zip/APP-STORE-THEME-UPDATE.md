# MRS App Store — theme update

This update applies the new storefront theme to the existing React/Vite app without replacing its catalog, API routes, APK hosting, reviews, developer publishing flow, or legal screens.

## Included
- Midnight navy canvas with soft blue/teal ambient lighting and a consistent surface/color system.
- Refined glass header and mobile navigation, editorial feature card, category controls, app cards/charts, publisher spotlight, footer, and matching detail/publish/legal modal surfaces.
- More visible focus states and reduced-motion support, with responsive styles retained.
- `server.ts` dev-preview host allowlist for the Arena preview (`.e2b.app`); production API behavior is unchanged.

## Apply to your repository
Extract this ZIP into the root of your existing `APPS-STORE` repo and allow it to replace the same-path files. The update intentionally does not include `node_modules`, build output, APKs, or your catalog data.

Then run:

```bash
npm install --legacy-peer-deps
npm run lint
npm run build
```

Commit and push the changed files to your configured `main`/`master` branch to trigger the existing GitHub Pages workflow.
